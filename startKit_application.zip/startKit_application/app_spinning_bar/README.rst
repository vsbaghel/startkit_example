The spinning bar
================

:scope: Example
:description: A simple demo using LEDs on the startKIT
:keywords: LEDs, startKIT


This is one of the simplest examples. It spins a sequence::

  | / - \

onto the 3x3 grid of LEDS. It just requires a single main program that
outputs a sequence of values to the LEDs. After each value is written the
program waits for a timer. The delay increases over time, slowing down the
spinning bar.
