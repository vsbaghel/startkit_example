Glowing LED pattern
===================

:scope: Example
:description: A simple demo using LED and PWM on the startKIT
:keywords: LEDs, startKIT, buttons

This example shows use of the LEDs and button on the startKIT by
showing a repeated glowing pattern. It uses ``module_starkit_gpio`` to
access the GPIO.
