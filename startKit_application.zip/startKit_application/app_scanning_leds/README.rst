LED scan example
================

:scope: Example
:description: A simple demo blinks each LED on the board individually
:keywords: LEDs, startKIT, buttons

This program blinks each of the startKITs onboard LEDs individually
to give new users an idea on how to address them.
This is meant to be similar to the Arduinos Blink sketch.
