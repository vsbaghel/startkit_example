startKIT developer board examples
=================================

:Latest release: 1.2.0rc0
:Maintainer: davelxmos
:Description: startKIT example programs


Required software (dependencies)
================================

  * sc_i2s (git@github.com:xcore/sc_i2s)
  * sc_i2c (git@github.com:xcore/sc_i2c)
  * sc_slicekit_support (https://github.com/xcore/sc_slicekit_support.git)
  * sw_audio_effects (git@github.com:xcore/sw_audio_effects)
  * sc_sdram_burst (https://github.com/xcore/sc_sdram_burst)
  * sc_capacitive_sensing (git@github.com:xcore/sc_capacitive_sensing)
  * sc_util (git://github.com/xcore/sc_util)

