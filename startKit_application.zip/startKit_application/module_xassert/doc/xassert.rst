.. code_rst_include:: src/xassert.h

