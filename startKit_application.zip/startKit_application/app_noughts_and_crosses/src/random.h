extern int my_random(int v);
