void strategy(chanend to_output);
