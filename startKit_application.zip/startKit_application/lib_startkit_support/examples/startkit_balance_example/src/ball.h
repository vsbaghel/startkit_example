// Copyright (c) 2015-2016, XMOS Ltd, All rights reserved
#ifndef __ball_h__
#define  __ball_h__

typedef interface ball_if {
  void  new_position(int x, int y, int z);
} ball_if;

#endif // __ball_h__
