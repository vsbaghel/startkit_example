// Copyright (c) 2015-2016, XMOS Ltd, All rights reserved
#define I2C_BIT_TIME 250
