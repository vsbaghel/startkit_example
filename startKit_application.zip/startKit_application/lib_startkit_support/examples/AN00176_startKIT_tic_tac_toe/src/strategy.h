// Copyright (c) 2015-2016, XMOS Ltd, All rights reserved
void strategy(chanend to_output);
