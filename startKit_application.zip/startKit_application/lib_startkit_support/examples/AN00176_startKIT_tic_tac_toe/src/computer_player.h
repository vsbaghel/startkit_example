// Copyright (c) 2015-2016, XMOS Ltd, All rights reserved
#ifndef __computer_player_h__
#define __computer_player_h__
#include "game.h"
#include "startkit_gpio.h"

[[combinable]]
void computer_player(client player_if);

#endif // __computer_player_h__
